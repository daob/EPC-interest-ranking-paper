rm(list=ls())
library(plyr)


set.seed(5648595823)

setwd("~/Dropbox/Jeroen-Invariance/simulation")
system("export WINEDEBUG=-all")


get_data <- function(n, J, delta=0) {
  z <- rnorm(n)
  x <- z + rnorm(n)
  
  y <- as.data.frame(matrix(rbinom(n*J, 1, plogis(x)), n))
  if(delta != 0) # generate DIF in V1
    y$V1  <- rbinom(n, 1, plogis(x + delta*z))
  y$z <- z
  
  y  
}


sim <- function(nobs, delta) {
  
  dat <- get_data(n=nobs, J=4, delta=delta)
  write.table(dat, "test_data.dat", col.names=TRUE, row.names=FALSE, quote=FALSE)
  
  system('export WINEDEBUG=-all; /Applications/Wine.app/Contents/Resources/bin/wine "/Users/daob/.wine/drive_c/Program Files/LatentGOLD5.0/lg50.exe" test_model.lgs', wait = TRUE)
  system("awk '/EPC\\(other\\)/,/Iteration Detail/' test_model.lst | tail +3 > epc.tab")
  system("sed -i '' -e '$ d' epc.tab")
  
  epc_other <- read.table("epc.tab", header=FALSE, sep="\t", stringsAsFactors = FALSE)
  rownames(epc_other) <- apply(epc_other[,1:3], 1, paste, collapse="")
  
  misspec <- paste("V", 1:4, "<-z", sep="")
  
  epc_other_p1 <- epc_other[misspec, "V4"]
  estimates <- scan("test_parameters.txt", what=double(), quiet = TRUE)
  
  c(est_=estimates, epc_other_=epc_other_p1, score=epc_other[misspec, "V13"])
}

conditions <- expand.grid(nobs=c(250, 500, 1000), delta=c(0, 0.5, 1))
nsim <- 200

system.time(res <- daply(conditions, .variables = 1:2, .fun = function(cond) { 
  cat(sprintf("\nnobs: %d; delta: %1.1f\n", cond[,'nobs'] , cond[,'delta'] ))

  t0 <- system.time(res <- ldply(1:nsim, function(isim) sim(cond[,'nobs'] , cond[,'delta'] ), .progress="text"))
  filename <- sprintf("results/res_%d_%1.1f.dat", cond[,'nobs'] , cond[,'delta'] )
  write.table(res, filename, sep="\t", row.names=FALSE)
  system(sprintf("gzip %s", filename))
  cat(sprintf("Time taken: %1.3fs.\n", t0['elapsed']))

  cbind(median_ests = apply(res, 2, median, na.rm=TRUE), mean_ests=apply(res, 2, mean, na.rm=TRUE), sd_ests=apply(res, 2, sd, na.rm=TRUE))
}))

res[,,,'median_ests']

save(res, file="results_simulation_5648595823.rdata")

library(xtable)

res[,,'score1','mean_ests']

round(aperm(res[,,c("est_1","epc_other_1"),'mean_ests'], c(3,2,1)), 3)



